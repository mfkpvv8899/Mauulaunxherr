package com.meu.launcher

import android.content.*
import android.graphics.BitmapFactory
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.net.Uri
import android.os.Bundle
import android.os.SystemClock
import android.service.notification.NotificationListenerService
import android.util.LruCache
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.Crossfade
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.time.LocalDate
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlin.math.abs
import java.time.format.TextStyle as JTextStyle

val CATS = listOf("Jogos", "Websites", "Social", "IA")
const val OTHERS = "Outros"
const val HIDDEN = "Oculto"
val EASE_BACK = CubicBezierEasing(0.34f, 1.56f, 0.64f, 1f)

data class AppInfo(val pkg: String, val label: String)

class Music(
    val title: String, val artist: String, val art: ImageBitmap?, val playing: Boolean,
    val pos: Long, val dur: Long, val controller: MediaController
)

class MusicUi(val granted: Boolean, val music: Music?)

class ArtCache { var key = ""; var art: ImageBitmap? = null }

/** Serviço vazio: só serve para o Android liberar a leitura da música que está tocando. */
class MediaListener : NotificationListenerService()

class Store(ctx: Context) {
    private val p = ctx.getSharedPreferences("launcher", 0)
    fun cat(pkg: String): String? = p.getString("c_$pkg", null)
    fun setCat(pkg: String, c: String?) =
        p.edit().apply { if (c == null) remove("c_$pkg") else putString("c_$pkg", c) }.apply()
    fun hidden(): Set<String> = p.getStringSet("hidden", emptySet())!!
    fun setHidden(pkg: String, h: Boolean) {
        val s = hidden().toMutableSet()
        if (h) s.add(pkg) else s.remove(pkg)
        p.edit().putStringSet("hidden", s).apply()
    }
    fun dock(): List<String> = (p.getString("dock", "") ?: "").split(",").filter { it.isNotEmpty() }
    fun setDock(l: List<String>) = p.edit().putString("dock", l.joinToString(",")).apply()
}

fun loadApps(ctx: Context): List<AppInfo> {
    val pm = ctx.packageManager
    val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    return pm.queryIntentActivities(i, 0)
        .map { AppInfo(it.activityInfo.packageName, it.loadLabel(pm).toString()) }
        .filter { it.pkg != ctx.packageName }
        .distinctBy { it.pkg }
        .sortedBy { it.label.lowercase() }
}

object IconCache {
    private val c = LruCache<String, ImageBitmap>(200)
    fun get(ctx: Context, pkg: String): ImageBitmap =
        c[pkg] ?: ctx.packageManager.getApplicationIcon(pkg)
            .toBitmap(108, 108).asImageBitmap().also { c.put(pkg, it) }
}

fun launchApp(ctx: Context, pkg: String) {
    val i = ctx.packageManager.getLaunchIntentForPackage(pkg)
    if (i != null) ctx.startActivity(i)
}

fun savePhoto(c: Context, u: Uri) {
    c.contentResolver.openInputStream(u)?.use { i ->
        File(c.filesDir, "center.img").outputStream().use { i.copyTo(it) }
    }
}

fun loadPhoto(c: Context): ImageBitmap? {
    val f = File(c.filesDir, "center.img")
    if (!f.exists()) return null
    val b = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    BitmapFactory.decodeFile(f.path, b)
    var s = 1
    while (b.outWidth / s > 1000) s *= 2
    return BitmapFactory.decodeFile(f.path, BitmapFactory.Options().apply { inSampleSize = s })
        ?.asImageBitmap()
}

fun fmt(ms: Long): String {
    val s = (ms / 1000).coerceAtLeast(0)
    return "%d:%02d".format(s / 60, s % 60)
}

fun readMusic(ctx: Context, cache: ArtCache): MusicUi {
    if (!NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName)) {
        return MusicUi(false, null)
    }
    val c: MediaController? = try {
        val msm = ctx.getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager
        val l = msm.getActiveSessions(ComponentName(ctx, MediaListener::class.java))
        l.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING } ?: l.firstOrNull()
    } catch (e: Exception) {
        null
    }
    if (c == null) return MusicUi(true, null)
    val m = c.metadata ?: return MusicUi(true, null)
    val title = m.getString(MediaMetadata.METADATA_KEY_TITLE) ?: "Sem título"
    val key = c.packageName + "|" + title
    if (key != cache.key || cache.art == null) {
        cache.key = key
        cache.art = (m.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
            ?: m.getBitmap(MediaMetadata.METADATA_KEY_ART))?.asImageBitmap()
    }
    val st = c.playbackState
    val playing = st?.state == PlaybackState.STATE_PLAYING
    var pos = st?.position ?: 0L
    if (playing && st != null) {
        pos += ((SystemClock.elapsedRealtime() - st.lastPositionUpdateTime) * st.playbackSpeed).toLong()
    }
    val artist = m.getString(MediaMetadata.METADATA_KEY_ARTIST)
        ?: m.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST) ?: ""
    val dur = m.getLong(MediaMetadata.METADATA_KEY_DURATION)
    return MusicUi(true, Music(title, artist, cache.art, playing, pos, dur, c))
}

@Composable
fun rememberMusic(ctx: Context): State<MusicUi> = produceState(MusicUi(true, null)) {
    val cache = ArtCache()
    while (true) {
        value = withContext(Dispatchers.Default) { readMusic(ctx, cache) }
        delay(1000)
    }
}

/** Entrada animada: sobe/desce com leve "quique" e aparece com fade. */
@Composable
fun Modifier.reveal(visible: Boolean, delayMs: Int = 0, fromY: Float = 60f): Modifier {
    val a by animateFloatAsState(
        if (visible) 1f else 0f, tween(450, delayMillis = delayMs), label = "a"
    )
    val y by animateFloatAsState(
        if (visible) 0f else fromY, tween(600, delayMillis = delayMs, easing = EASE_BACK), label = "y"
    )
    return this.graphicsLayer { alpha = a; translationY = y }
}

/** Efeito de apertar: encolhe e volta com mola. */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun Modifier.bounceClick(onLong: () -> Unit = {}, onClick: () -> Unit): Modifier {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val s by animateFloatAsState(
        if (pressed) 0.82f else 1f,
        spring(Spring.DampingRatioMediumBouncy, Spring.StiffnessMedium), label = "s"
    )
    return this
        .graphicsLayer { scaleX = s; scaleY = s }
        .combinedClickable(
            interactionSource = src, indication = null,
            onClick = onClick, onLongClick = onLong
        )
}

@Composable
fun Glyph(kind: Int, sz: Dp, color: Color = Color.Black) {
    Canvas(Modifier.size(sz)) {
        val w = size.width
        val h = size.height
        when (kind) {
            0 -> drawPath(Path().apply {
                moveTo(w * .25f, h * .15f); lineTo(w * .85f, h * .5f); lineTo(w * .25f, h * .85f); close()
            }, color)
            1 -> {
                drawRect(color, Offset(w * .2f, h * .15f), Size(w * .2f, h * .7f))
                drawRect(color, Offset(w * .6f, h * .15f), Size(w * .2f, h * .7f))
            }
            2 -> {
                drawPath(Path().apply {
                    moveTo(w * .1f, h * .2f); lineTo(w * .65f, h * .5f); lineTo(w * .1f, h * .8f); close()
                }, color)
                drawRect(color, Offset(w * .72f, h * .2f), Size(w * .14f, h * .6f))
            }
            else -> {
                drawPath(Path().apply {
                    moveTo(w * .9f, h * .2f); lineTo(w * .35f, h * .5f); lineTo(w * .9f, h * .8f); close()
                }, color)
                drawRect(color, Offset(w * .14f, h * .2f), Size(w * .14f, h * .6f))
            }
        }
    }
}

@Composable
fun AppIcon(pkg: String, size: Dp) {
    val ctx = LocalContext.current
    val icon by produceState<ImageBitmap?>(null, pkg) {
        value = withContext(Dispatchers.Default) { runCatching { IconCache.get(ctx, pkg) }.getOrNull() }
    }
    val a by animateFloatAsState(if (icon != null) 1f else 0f, tween(300), label = "ia")
    Box(Modifier.size(size).graphicsLayer { alpha = a }) {
        icon?.let { Image(it, null, Modifier.fillMaxSize()) }
    }
}

@Composable
fun AppMenu(open: Boolean, onClose: () -> Unit, app: AppInfo, store: Store, onChange: () -> Unit) {
    val ctx = LocalContext.current
    val isHidden = app.pkg in store.hidden()
    val dock = store.dock()
    DropdownMenu(open, onClose) {
        (CATS + OTHERS).forEach { c ->
            DropdownMenuItem(text = { Text("Mover para $c") }, onClick = {
                store.setCat(app.pkg, if (c == OTHERS) null else c); onClose(); onChange()
            })
        }
        if (app.pkg in dock) {
            DropdownMenuItem(text = { Text("Remover do dock") }, onClick = {
                store.setDock(dock - app.pkg); onClose(); onChange()
            })
        } else if (dock.size < 5) {
            DropdownMenuItem(text = { Text("Adicionar ao dock") }, onClick = {
                store.setDock(dock + app.pkg); onClose(); onChange()
            })
        }
        DropdownMenuItem(text = { Text(if (isHidden) "Mostrar app" else "Ocultar app") }, onClick = {
            store.setHidden(app.pkg, !isHidden); onClose(); onChange()
        })
        DropdownMenuItem(text = { Text("Desinstalar") }, onClick = {
            onClose()
            ctx.startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:${app.pkg}")))
        })
    }
}

@Composable
fun AppCell(app: AppInfo, index: Int, store: Store, onChange: () -> Unit) {
    val ctx = LocalContext.current
    var menu by remember { mutableStateOf(false) }
    var shown by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { shown = true }
    Column(
        Modifier.padding(vertical = 8.dp)
            .reveal(shown, (index % 16) * 35, 40f)
            .bounceClick(onLong = { menu = true }) { launchApp(ctx, app.pkg) },
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        AppIcon(app.pkg, 52.dp)
        Text(app.label, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, color = Color.Black)
        AppMenu(menu, { menu = false }, app, store, onChange)
    }
}

@Composable
fun DockIcon(app: AppInfo, index: Int, started: Boolean, store: Store, onChange: () -> Unit) {
    val ctx = LocalContext.current
    var menu by remember { mutableStateOf(false) }
    Box(
        Modifier.reveal(started, 350 + index * 80, 120f)
            .bounceClick(onLong = { menu = true }) { launchApp(ctx, app.pkg) }
    ) {
        AppIcon(app.pkg, 50.dp)
        AppMenu(menu, { menu = false }, app, store, onChange)
    }
}

@Composable
fun Dock(apps: List<AppInfo>, started: Boolean, store: Store, onChange: () -> Unit) {
    Row(
        Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
            .reveal(started, 200, 220f)
            .fillMaxWidth().height(78.dp)
            .shadow(10.dp, RoundedCornerShape(30.dp), clip = false)
            .clip(RoundedCornerShape(30.dp)).background(Color.White)
            .padding(horizontal = 14.dp),
        horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (apps.isEmpty()) {
            Text("Segure um app e escolha \"Adicionar ao dock\"", fontSize = 12.sp, color = Color.Gray)
        }
        apps.forEachIndexed { i, a -> DockIcon(a, i, started, store, onChange) }
    }
}

@Composable
fun Dots(page: Int) {
    Row(Modifier.fillMaxWidth().padding(top = 6.dp), horizontalArrangement = Arrangement.Center) {
        for (i in 0..1) {
            val w by animateDpAsState(
                if (page == i) 20.dp else 6.dp,
                spring(Spring.DampingRatioMediumBouncy), label = "w"
            )
            val col by animateColorAsState(
                if (page == i) Color.Black else Color(0xFFC8C8C8), label = "c"
            )
            Box(Modifier.padding(horizontal = 3.dp).height(6.dp).width(w).clip(CircleShape).background(col))
        }
    }
}

@Composable
fun Chip(label: String, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val bg by animateColorAsState(if (selected) Color.Black else Color.White, tween(250), label = "bg")
    val fg by animateColorAsState(if (selected) Color.White else Color.Black, tween(250), label = "fg")
    val sc by animateFloatAsState(
        if (selected) 1.06f else 1f, spring(Spring.DampingRatioMediumBouncy), label = "sc"
    )
    Box(
        modifier.graphicsLayer { scaleX = sc; scaleY = sc }
            .bounceClick(onClick = onClick)
            .clip(RoundedCornerShape(50)).background(bg)
            .padding(horizontal = 16.dp, vertical = 8.dp)
    ) { Text(label, color = fg, fontSize = 13.sp) }
}

@Composable
fun Panel(modifier: Modifier, content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier.fillMaxWidth()
            .shadow(6.dp, RoundedCornerShape(28.dp), clip = false)
            .clip(RoundedCornerShape(28.dp)).background(Color.White).padding(18.dp),
        content = content
    )
}

@Composable
fun MusicBody(m: Music) {
    val inf = rememberInfiniteTransition(label = "inf")
    val pulse = inf.animateFloat(
        1f, 1.06f, infiniteRepeatable(tween(900, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "pulse"
    )
    val amp = animateFloatAsState(if (m.playing) 1f else 0f, tween(400), label = "amp")
    val prog = animateFloatAsState(
        if (m.dur > 0) (m.pos.toFloat() / m.dur).coerceIn(0f, 1f) else 0f,
        tween(1000, easing = LinearEasing), label = "prog"
    )
    val tc = m.controller.transportControls
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier.size(84.dp)
                .graphicsLayer {
                    val s = 1f + (pulse.value - 1f) * amp.value
                    scaleX = s; scaleY = s
                }
                .clip(RoundedCornerShape(20.dp)).background(Color(0xFFEDEDED))
        ) {
            m.art?.let { Image(it, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop) }
        }
        Spacer(Modifier.width(14.dp))
        Column {
            Crossfade(targetState = m.title, label = "title") { t ->
                Text(t, fontSize = 17.sp, fontWeight = FontWeight.Bold, maxLines = 1,
                    overflow = TextOverflow.Ellipsis, color = Color.Black)
            }
            Text(m.artist, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, color = Color.Gray)
        }
    }
    Spacer(Modifier.height(16.dp))
    Box(Modifier.fillMaxWidth().height(5.dp).clip(RoundedCornerShape(3.dp)).background(Color(0xFFE6E6E6))) {
        Box(Modifier.fillMaxWidth(prog.value).fillMaxHeight().background(Color.Black))
    }
    Spacer(Modifier.height(6.dp))
    Row(Modifier.fillMaxWidth()) {
        Text(fmt(m.pos), fontSize = 11.sp, color = Color.Gray)
        Spacer(Modifier.weight(1f))
        Text(fmt(m.dur), fontSize = 11.sp, color = Color.Gray)
    }
    Spacer(Modifier.height(10.dp))
    Row(
        Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.bounceClick { tc.skipToPrevious() }.padding(10.dp)) { Glyph(3, 24.dp) }
        Box(
            Modifier.size(56.dp).bounceClick { if (m.playing) tc.pause() else tc.play() }
                .clip(CircleShape).background(Color.Black),
            contentAlignment = Alignment.Center
        ) {
            Crossfade(targetState = m.playing, label = "pp") { p ->
                Glyph(if (p) 1 else 0, 22.dp, Color.White)
            }
        }
        Box(Modifier.bounceClick { tc.skipToNext() }.padding(10.dp)) { Glyph(2, 24.dp) }
    }
}

@Composable
fun MusicCard(modifier: Modifier) {
    val ctx = LocalContext.current
    val ui by rememberMusic(ctx)
    Panel(modifier) {
        val m = ui.music
        if (!ui.granted) {
            Text("Mostrar a música que está tocando", fontSize = 15.sp,
                fontWeight = FontWeight.Bold, color = Color.Black)
            Spacer(Modifier.height(4.dp))
            Text("Libere o acesso às notificações para o launcher ler o player.",
                fontSize = 12.sp, color = Color.Gray)
            Spacer(Modifier.height(12.dp))
            Box(
                Modifier.bounceClick {
                    ctx.startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"))
                }.clip(RoundedCornerShape(50)).background(Color.Black)
                    .padding(horizontal = 18.dp, vertical = 10.dp)
            ) { Text("Permitir acesso", color = Color.White, fontSize = 13.sp) }
        } else if (m == null) {
            Text("Nada tocando agora", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = Color.Black)
            Text("Abra um player de música e ele aparece aqui.", fontSize = 12.sp, color = Color.Gray)
        } else {
            MusicBody(m)
        }
    }
}

@Composable
fun Day(d: Int, isToday: Boolean, visible: Boolean, idx: Int) {
    val s = animateFloatAsState(
        if (visible) 1f else 0f,
        tween(500, delayMillis = 150 + idx * 14, easing = EASE_BACK), label = "d"
    )
    val pulse = if (isToday) {
        rememberInfiniteTransition(label = "t").animateFloat(
            1f, 1.12f, infiniteRepeatable(tween(1100, easing = FastOutSlowInEasing), RepeatMode.Reverse),
            label = "tp"
        ).value
    } else 1f
    Box(
        Modifier.fillMaxSize().padding(2.dp)
            .graphicsLayer {
                val k = s.value * pulse
                scaleX = k; scaleY = k; alpha = s.value.coerceIn(0f, 1f)
            }
            .clip(CircleShape).background(if (isToday) Color.Black else Color.Transparent),
        contentAlignment = Alignment.Center
    ) {
        Text("$d", fontSize = 12.sp, color = if (isToday) Color.White else Color.Black)
    }
}

@Composable
fun CalendarCard(visible: Boolean, modifier: Modifier) {
    val today = remember { LocalDate.now() }
    val offset = today.withDayOfMonth(1).dayOfWeek.value % 7
    val n = today.lengthOfMonth()
    val rows = (offset + n + 6) / 7
    val title = today.month.getDisplayName(JTextStyle.FULL, Locale("pt", "BR")).uppercase() + " " + today.year
    Panel(modifier) {
        Text(title, fontSize = 13.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp, color = Color.Black)
        Spacer(Modifier.height(10.dp))
        Row(Modifier.fillMaxWidth()) {
            listOf("D", "S", "T", "Q", "Q", "S", "S").forEach {
                Text(it, modifier = Modifier.weight(1f), textAlign = TextAlign.Center,
                    fontSize = 11.sp, color = Color.Gray)
            }
        }
        for (r in 0 until rows) {
            Row(Modifier.fillMaxWidth()) {
                for (c in 0..6) {
                    val d = r * 7 + c - offset + 1
                    Box(Modifier.weight(1f).aspectRatio(1f), contentAlignment = Alignment.Center) {
                        if (d in 1..n) Day(d, d == today.dayOfMonth, visible, r * 7 + c)
                    }
                }
            }
        }
    }
}

@Composable
fun WidgetsPage(visible: Boolean) {
    Column(
        Modifier.fillMaxSize().padding(horizontal = 16.dp).verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Spacer(Modifier.height(8.dp))
        MusicCard(Modifier.reveal(visible, 0))
        CalendarCard(visible, Modifier.reveal(visible, 120))
        Spacer(Modifier.height(8.dp))
    }
}

class MainActivity : ComponentActivity() {
    private val tick = mutableIntStateOf(0)
    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) { tick.intValue++ }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        val f = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addDataScheme("package")
        }
        ContextCompat.registerReceiver(this, receiver, f, ContextCompat.RECEIVER_EXPORTED)
        setContent { MaterialTheme(colorScheme = lightColorScheme()) { Home(tick.intValue) } }
    }

    override fun onDestroy() {
        unregisterReceiver(receiver)
        super.onDestroy()
    }
}

@Composable
fun Home(tick: Int) {
    val ctx = LocalContext.current
    val store = remember { Store(ctx) }
    val scope = rememberCoroutineScope()
    var rev by remember { mutableIntStateOf(0) }
    var apps by remember { mutableStateOf(emptyList<AppInfo>()) }
    var tab by remember { mutableStateOf(CATS[0]) }
    var secret by remember { mutableStateOf(false) }
    var taps by remember { mutableIntStateOf(0) }
    var photo by remember { mutableStateOf(loadPhoto(ctx)) }
    var started by remember { mutableStateOf(false) }
    val clockFmt = remember { DateTimeFormatter.ofPattern("HH:mm") }
    var time by remember { mutableStateOf(LocalTime.now().format(clockFmt)) }
    val dateStr = remember(time) {
        LocalDate.now().format(DateTimeFormatter.ofPattern("EEEE, d 'de' MMMM", Locale("pt", "BR")))
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) { savePhoto(ctx, uri); photo = loadPhoto(ctx) }
    }

    LaunchedEffect(Unit) { started = true }
    LaunchedEffect(tick) { apps = withContext(Dispatchers.Default) { loadApps(ctx) } }
    LaunchedEffect(Unit) {
        while (true) { time = LocalTime.now().format(clockFmt); delay(20_000) }
    }

    val pager = rememberPagerState(pageCount = { 2 })
    BackHandler(pager.currentPage == 1) { scope.launch { pager.animateScrollToPage(0) } }
    BackHandler(secret && pager.currentPage == 0) { secret = false; if (tab == HIDDEN) tab = CATS[0] }

    val hidden = remember(rev, apps) { store.hidden() }
    val dockApps = remember(rev, apps) { store.dock().mapNotNull { p -> apps.firstOrNull { it.pkg == p } } }
    val list = remember(apps, tab, rev, hidden) {
        apps.filter { a ->
            when (tab) {
                HIDDEN -> a.pkg in hidden
                OTHERS -> a.pkg !in hidden && store.cat(a.pkg) == null
                else -> a.pkg !in hidden && store.cat(a.pkg) == tab
            }
        }
    }

    val pop = animateFloatAsState(
        if (started) 1f else 0f,
        spring(Spring.DampingRatioLowBouncy, Spring.StiffnessLow), label = "pop"
    )
    val inf = rememberInfiniteTransition(label = "float")
    val floatY = inf.animateFloat(
        -6f, 6f, infiniteRepeatable(tween(2600, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "fy"
    )

    Column(
        Modifier.fillMaxSize().background(Color(0xFFF7F8FA))
            .statusBarsPadding().navigationBarsPadding()
    ) {
        HorizontalPager(state = pager, modifier = Modifier.weight(1f)) { page ->
            val off = (pager.currentPage - page) + pager.currentPageOffsetFraction
            Box(
                Modifier.fillMaxSize().graphicsLayer {
                    val a = abs(off).coerceIn(0f, 1f)
                    alpha = 1f - a * 0.6f
                    scaleX = 1f - a * 0.1f
                    scaleY = 1f - a * 0.1f
                    translationX = off * size.width * 0.2f
                }
            ) {
                if (page == 0) {
                    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
                        Spacer(Modifier.height(8.dp))
                        Text(
                            time, fontSize = 48.sp, fontWeight = FontWeight.Black, color = Color.Black,
                            modifier = Modifier.reveal(started, 0, -40f).clickable(
                                interactionSource = remember { MutableInteractionSource() },
                                indication = null
                            ) {
                                taps++
                                if (taps >= 5) { taps = 0; secret = true; tab = HIDDEN }
                            }
                        )
                        Text(dateStr, fontSize = 13.sp, color = Color.Gray,
                            modifier = Modifier.reveal(started, 80, -30f))
                        Spacer(Modifier.height(10.dp))
                        Box(
                            Modifier.align(Alignment.CenterHorizontally).size(140.dp)
                                .graphicsLayer {
                                    scaleX = pop.value; scaleY = pop.value
                                    alpha = pop.value.coerceIn(0f, 1f)
                                    translationY = floatY.value
                                }
                                .bounceClick { picker.launch("image/*") }
                                .clip(RoundedCornerShape(36.dp)).background(Color.White),
                            contentAlignment = Alignment.Center
                        ) {
                            val p = photo
                            if (p != null) Image(p, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                            else Text("Toque para\nescolher foto", color = Color.Gray,
                                fontSize = 13.sp, textAlign = TextAlign.Center)
                        }
                        Spacer(Modifier.height(14.dp))

                        val tabs = CATS + OTHERS + if (secret) listOf(HIDDEN) else emptyList()
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            itemsIndexed(tabs) { i, t ->
                                Chip(t, tab == t, Modifier.reveal(started, 200 + i * 50, 30f)) { tab = t }
                            }
                        }
                        Spacer(Modifier.height(8.dp))

                        LazyVerticalGrid(GridCells.Fixed(4), Modifier.fillMaxSize()) {
                            itemsIndexed(list, key = { _, a -> a.pkg }) { i, app ->
                                AppCell(app, i, store) { rev++ }
                            }
                        }
                    }
                } else {
                    WidgetsPage(visible = pager.currentPage == 1)
                }
            }
        }
        Dots(pager.currentPage)
        Dock(dockApps, started, store) { rev++ }
    }
}
