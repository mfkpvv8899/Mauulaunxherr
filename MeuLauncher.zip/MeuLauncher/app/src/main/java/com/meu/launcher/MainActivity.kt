package com.meu.launcher

import android.content.*
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.util.LruCache
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.io.File
import java.time.LocalTime
import java.time.format.DateTimeFormatter

val CATS = listOf("Jogos", "Websites", "Social", "IA")
const val OTHERS = "Outros"
const val HIDDEN = "Oculto"

data class AppInfo(val pkg: String, val label: String)

/** Guarda categoria de cada app e lista de ocultos (SharedPreferences = leve). */
class Store(ctx: Context) {
    private val p = ctx.getSharedPreferences("launcher", 0)
    fun cat(pkg: String): String? = p.getString("c_$pkg", null)
    fun setCat(pkg: String, c: String?) =
        p.edit().apply { if (c == null) remove("c_$pkg") else putString("c_$pkg", c) }.apply()
    fun hidden(): Set<String> = p.getStringSet("hidden", emptySet())!!
    fun setHidden(pkg: String, h: Boolean) {
        val s = hidden().toMutableSet()
        if (h) s.add(pkg) else s.remove(pkg)
        p.edit().putStringSet("hidden", s).apply()
    }
}

fun loadApps(ctx: Context): List<AppInfo> {
    val pm = ctx.packageManager
    val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    return pm.queryIntentActivities(i, 0)
        .map { AppInfo(it.activityInfo.packageName, it.loadLabel(pm).toString()) }
        .filter { it.pkg != ctx.packageName }
        .distinctBy { it.pkg }
        .sortedBy { it.label.lowercase() }
}

/** Cache de ícones: carrega 1x em segundo plano, evita travar a rolagem. */
object IconCache {
    private val c = LruCache<String, ImageBitmap>(200)
    fun get(ctx: Context, pkg: String): ImageBitmap =
        c[pkg] ?: ctx.packageManager.getApplicationIcon(pkg)
            .toBitmap(108, 108).asImageBitmap().also { c.put(pkg, it) }
}

fun savePhoto(c: Context, u: Uri) {
    c.contentResolver.openInputStream(u)?.use { i ->
        File(c.filesDir, "center.img").outputStream().use { i.copyTo(it) }
    }
}

fun loadPhoto(c: Context): ImageBitmap? {
    val f = File(c.filesDir, "center.img")
    if (!f.exists()) return null
    val b = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    BitmapFactory.decodeFile(f.path, b)
    var s = 1
    while (b.outWidth / s > 1000) s *= 2
    return BitmapFactory.decodeFile(f.path, BitmapFactory.Options().apply { inSampleSize = s })
        ?.asImageBitmap()
}

class MainActivity : ComponentActivity() {
    private val tick = mutableIntStateOf(0)
    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) { tick.intValue++ }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val f = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addDataScheme("package")
        }
        ContextCompat.registerReceiver(this, receiver, f, ContextCompat.RECEIVER_EXPORTED)
        setContent { MaterialTheme(colorScheme = lightColorScheme()) { Home(tick.intValue) } }
    }

    override fun onDestroy() {
        unregisterReceiver(receiver)
        super.onDestroy()
    }
}

@Composable
fun Home(tick: Int) {
    val ctx = LocalContext.current
    val store = remember { Store(ctx) }
    var rev by remember { mutableIntStateOf(0) }
    var apps by remember { mutableStateOf(emptyList<AppInfo>()) }
    var tab by remember { mutableStateOf(CATS[0]) }
    var secret by remember { mutableStateOf(false) }
    var taps by remember { mutableIntStateOf(0) }
    var photo by remember { mutableStateOf(loadPhoto(ctx)) }
    var time by remember { mutableStateOf("") }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) { savePhoto(ctx, uri); photo = loadPhoto(ctx) }
    }

    LaunchedEffect(tick) { apps = withContext(Dispatchers.Default) { loadApps(ctx) } }
    LaunchedEffect(Unit) {
        val fmt = DateTimeFormatter.ofPattern("HH:mm")
        while (true) { time = LocalTime.now().format(fmt); delay(20_000) }
    }
    BackHandler(secret) { secret = false; if (tab == HIDDEN) tab = CATS[0] }

    val hidden = remember(rev, apps) { store.hidden() }
    val list = remember(apps, tab, rev, hidden) {
        apps.filter { a ->
            when (tab) {
                HIDDEN -> a.pkg in hidden
                OTHERS -> a.pkg !in hidden && store.cat(a.pkg) == null
                else -> a.pkg !in hidden && store.cat(a.pkg) == tab
            }
        }
    }

    Column(
        Modifier.fillMaxSize().background(Color(0xFFF7F8FA))
            .statusBarsPadding().navigationBarsPadding().padding(16.dp)
    ) {
        // Relógio: toque 5x = abre a área secreta de ocultos
        Text(
            time, fontSize = 48.sp, fontWeight = FontWeight.Black, color = Color.Black,
            modifier = Modifier.clickable(
                interactionSource = remember { MutableInteractionSource() }, indication = null
            ) {
                taps++
                if (taps >= 5) { taps = 0; secret = true; tab = HIDDEN }
            }
        )
        Spacer(Modifier.height(12.dp))

        // Imagem central: toque para escolher
        Box(
            Modifier.align(Alignment.CenterHorizontally).size(170.dp)
                .clip(RoundedCornerShape(40.dp)).background(Color.White)
                .clickable { picker.launch("image/*") },
            contentAlignment = Alignment.Center
        ) {
            val p = photo
            if (p != null) Image(p, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            else Text("Toque para\nescolher foto", color = Color.Gray, fontSize = 13.sp)
        }
        Spacer(Modifier.height(16.dp))

        val tabs = CATS + OTHERS + if (secret) listOf(HIDDEN) else emptyList()
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(tabs) { t ->
                FilterChip(
                    selected = tab == t, onClick = { tab = t }, label = { Text(t) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = Color.Black, selectedLabelColor = Color.White,
                        containerColor = Color.White
                    )
                )
            }
        }
        Spacer(Modifier.height(8.dp))

        LazyVerticalGrid(GridCells.Fixed(4), Modifier.fillMaxSize()) {
            items(list, key = { it.pkg }) { app ->
                AppCell(app, store, app.pkg in hidden) { rev++ }
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun AppCell(app: AppInfo, store: Store, isHidden: Boolean, onChange: () -> Unit) {
    val ctx = LocalContext.current
    var menu by remember { mutableStateOf(false) }
    val icon by produceState<ImageBitmap?>(null, app.pkg) {
        value = withContext(Dispatchers.Default) { runCatching { IconCache.get(ctx, app.pkg) }.getOrNull() }
    }
    Column(
        Modifier.padding(vertical = 8.dp).combinedClickable(
            onClick = { ctx.packageManager.getLaunchIntentForPackage(app.pkg)?.let(ctx::startActivity) },
            onLongClick = { menu = true }
        ),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        icon?.let { Image(it, null, Modifier.size(52.dp)) } ?: Spacer(Modifier.size(52.dp))
        Text(app.label, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, color = Color.Black)

        DropdownMenu(menu, { menu = false }) {
            (CATS + OTHERS).forEach { c ->
                DropdownMenuItem(text = { Text("Mover para $c") }, onClick = {
                    store.setCat(app.pkg, if (c == OTHERS) null else c); menu = false; onChange()
                })
            }
            DropdownMenuItem(text = { Text(if (isHidden) "Mostrar app" else "Ocultar app") }, onClick = {
                store.setHidden(app.pkg, !isHidden); menu = false; onChange()
            })
            DropdownMenuItem(text = { Text("Desinstalar") }, onClick = {
                menu = false
                ctx.startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:${app.pkg}")))
            })
        }
    }
}
